import { invoke } from '@tauri-apps/api/core';

let selectedFiles = [];
let processedImages = [];
let downloadPath = '';
let settings = {
  filenamePrefix: 'none',
  customPrefix: '',
  keepOriginalFilename: false
};

const geocodeCache = new Map();

function showToast(message, type = 'success') {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.className = 'toast' + (type === 'error' ? ' error' : '');
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3000);
}

function showLoading(show, text = 'Processing...', status = '') {
  const overlay = document.getElementById('loading-overlay');
  if (show) {
    overlay.querySelector('.loading-text').textContent = text;
    document.getElementById('loading-status').textContent = status;
    overlay.classList.add('show');
  } else {
    overlay.classList.remove('show');
  }
}

function updateLoadingStatus(status) {
  document.getElementById('loading-status').textContent = status;
}

async function initDownloadPath() {
  try {
    downloadPath = await invoke('get_default_download_path');
    document.getElementById('download-path').value = downloadPath;
  } catch (e) {
    downloadPath = '';
  }
}

async function selectDownloadPath() {
  try {
    const path = await invoke('select_download_path');
    if (path) {
      downloadPath = path;
      document.getElementById('download-path').value = path;
      showToast('Download path updated');
    }
  } catch (e) {
    showToast('Failed to select path', 'error');
  }
}

function handleFileSelect(e) {
  const files = Array.from(e.target.files).filter(f => f.type.startsWith('image/'));
  if (files.length > 0) {
    selectedFiles = files;
    updatePreview();
  }
}

function handleDrop(e) {
  e.preventDefault();
  const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/'));
  if (files.length > 0) {
    selectedFiles = [...selectedFiles, ...files];
    updatePreview();
  }
}

function updatePreview() {
  const preview = document.getElementById('preview-container');
  const empty = document.getElementById('empty-preview');
  const processBtn = document.getElementById('process-btn');

  if (selectedFiles.length > 0) {
    preview.style.display = 'grid';
    empty.style.display = 'none';
    processBtn.disabled = false;
    preview.innerHTML = '';
    selectedFiles.slice(0, 12).forEach((file, i) => {
      const item = document.createElement('div');
      item.className = 'preview-item';
      const img = document.createElement('img');
      img.src = URL.createObjectURL(file);
      const span = document.createElement('span');
      span.textContent = file.name;
      item.appendChild(img);
      item.appendChild(span);
      preview.appendChild(item);
    });
    if (selectedFiles.length > 12) {
      const more = document.createElement('div');
      more.className = 'preview-item';
      more.style.display = 'flex';
      more.style.alignItems = 'center';
      more.style.justifyContent = 'center';
      more.style.color = '#86868b';
      more.textContent = `+${selectedFiles.length - 12}`;
      preview.appendChild(more);
    }
  } else {
    preview.style.display = 'none';
    empty.style.display = 'block';
    processBtn.disabled = true;
  }
}

function extractExif(file) {
  return new Promise((resolve) => {
    if (typeof EXIF === 'undefined') {
      resolve({ hasExif: false, gps: null, location: null, placeName: null, timestamp: null });
      return;
    }
    try {
      EXIF.getData(file, function() {
        const result = { hasExif: false, gps: null, location: null, placeName: null, timestamp: null };
        const tags = EXIF.getAllTags(this);
        if (Object.keys(tags).length > 0) {
          result.hasExif = true;
          if (tags.DateTime) result.timestamp = tags.DateTime;
          else if (tags.DateTimeOriginal) result.timestamp = tags.DateTimeOriginal;
          if (tags.GPSLatitude && tags.GPSLongitude) {
            const lat = convertDMSToDD(tags.GPSLatitude, tags.GPSLatitudeRef);
            const lng = convertDMSToDD(tags.GPSLongitude, tags.GPSLongitudeRef);
            if (!isNaN(lat) && !isNaN(lng)) {
              result.gps = { lat, lng };
              result.location = `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
            }
          }
        }
        resolve(result);
      });
    } catch (e) {
      resolve({ hasExif: false, gps: null, location: null, placeName: null, timestamp: null });
    }
  });
}

function convertDMSToDD(dms, ref) {
  if (!dms || !ref) return NaN;
  const degrees = dms[0].numerator / dms[0].denominator;
  const minutes = dms[1].numerator / dms[1].denominator;
  const seconds = dms[2].numerator / dms[2].denominator;
  let dd = degrees + minutes / 60 + seconds / 3600;
  if (ref === 'S' || ref === 'W') dd = dd * -1;
  return dd;
}

async function reverseGeocode(lat, lng) {
  const cacheKey = `${lat.toFixed(4)},${lng.toFixed(4)}`;
  if (geocodeCache.has(cacheKey)) return geocodeCache.get(cacheKey);

  updateLoadingStatus(`Geocoding: ${lat.toFixed(4)}, ${lng.toFixed(4)}...`);

  // Try BigDataCloud first
  try {
    const resp = await fetch(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lng}&localityLanguage=en`);
    if (resp.ok) {
      const data = await resp.json();
      const parts = [];
      if (data.locality) parts.push(data.locality);
      if (data.city) parts.push(data.city);
      if (data.principalSubdivision) parts.push(data.principalSubdivision);
      if (data.countryName) parts.push(data.countryName);
      const place = parts.filter(Boolean).join(', ');
      if (place) {
        geocodeCache.set(cacheKey, place);
        return place;
      }
    }
  } catch (e) {}

  // Fallback to OpenStreetMap Nominatim
  try {
    const resp = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1&accept-language=en`, {
      headers: { 'User-Agent': 'GeoStamp/1.0' }
    });
    if (resp.ok) {
      const data = await resp.json();
      if (data.display_name) {
        geocodeCache.set(cacheKey, data.display_name);
        return data.display_name;
      }
    }
  } catch (e) {}

  return `${lat.toFixed(4)}N, ${lng.toFixed(4)}E`;
}

function generateFilename(exifData, index, originalName) {
  if (settings.keepOriginalFilename) return originalName;

  const serial = String(index + 1).padStart(3, '0');
  let prefix = '';

  switch (settings.filenamePrefix) {
    case 'time':
      prefix = exifData.timestamp ? exifData.timestamp.replace(/[:\s]/g, '') : 'Unknown';
      break;
    case 'location':
      prefix = exifData.placeName ? exifData.placeName.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 30) : 'Unknown';
      break;
    case 'custom':
      prefix = settings.customPrefix || 'GeoStamp';
      break;
    default:
      return originalName;
  }

  return `${prefix}_${serial}.jpg`;
}

async function processImages() {
  if (selectedFiles.length === 0) return;

  showLoading(true, 'Processing images...', 'Reading EXIF data...');
  processedImages = [];

  for (let i = 0; i < selectedFiles.length; i++) {
    const file = selectedFiles[i];
    updateLoadingStatus(`Processing ${i + 1}/${selectedFiles.length}: ${file.name}`);

    const exifData = await extractExif(file);

    if (exifData.gps) {
      try {
        exifData.placeName = await reverseGeocode(exifData.gps.lat, exifData.gps.lng);
      } catch (e) {}
    }

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();

    await new Promise((resolve, reject) => {
      img.onload = resolve;
      img.onerror = reject;
      img.src = URL.createObjectURL(file);
    });

    canvas.width = img.width;
    canvas.height = img.height + 120;
    ctx.drawImage(img, 0, 0);

    // Annotation area
    ctx.fillStyle = 'rgba(0,0,0,0.75)';
    ctx.fillRect(0, img.height, img.width, 120);

    const fontSize = Math.max(20, Math.min(32, img.width / 25));
    ctx.font = `bold ${fontSize}px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif`;
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'left';

    const maxTextWidth = img.width * 0.5;

    // Line 1: Location
    let line1 = exifData.placeName || exifData.location || 'Unknown Location';
    if (ctx.measureText(line1).width > maxTextWidth) {
      while (ctx.measureText(line1 + '...').width > maxTextWidth && line1.length > 3) {
        line1 = line1.slice(0, -1);
      }
      line1 += '...';
    }
    ctx.fillText(line1, 20, img.height + fontSize + 15);

    // Line 2: Coordinates | Time | Filename
    ctx.font = `normal ${fontSize * 0.6}px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif`;
    ctx.fillStyle = '#a0a0a0';
    const coords = exifData.gps ? `${exifData.gps.lat.toFixed(4)}N, ${exifData.gps.lng.toFixed(4)}E` : 'No GPS';
    const time = exifData.timestamp || 'No timestamp';
    const line2 = `${coords} | ${time} | ${file.name}`;
    let line2Text = line2;
    if (ctx.measureText(line2Text).width > maxTextWidth) {
      while (ctx.measureText(line2Text + '...').width > maxTextWidth && line2Text.length > 3) {
        line2Text = line2Text.slice(0, -1);
      }
      line2Text += '...';
    }
    ctx.fillText(line2Text, 20, img.height + fontSize + 15 + fontSize * 0.6 + 10);

    const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', 0.95));
    const newName = generateFilename(exifData, i, file.name);
    const newFile = new File([blob], newName, { type: 'image/jpeg' });
    processedImages.push({ file: newFile, exifData, originalName: file.name });

    URL.revokeObjectURL(img.src);
  }

  showLoading(false);
  displayResults();
  showToast(`Processed ${processedImages.length} images`);
}

function displayResults() {
  const grid = document.getElementById('results-grid');
  const empty = document.getElementById('empty-results');
  const downloadAllBtn = document.getElementById('download-all-btn');

  if (processedImages.length > 0) {
    grid.innerHTML = '';
    empty.style.display = 'none';
    downloadAllBtn.disabled = false;

    processedImages.forEach((item, index) => {
      const card = document.createElement('div');
      card.className = 'result-card';
      card.innerHTML = `
        <img src="${URL.createObjectURL(item.file)}" alt="${item.file.name}">
        <div class="info">
          <span class="name" title="${item.file.name}">${item.file.name}</span>
          <button class="download-btn" data-index="${index}" title="Download">
            <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
              <path stroke-linecap="round" stroke-linejoin="round" d="M4 16v1a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/>
            </svg>
          </button>
        </div>
      `;
      grid.appendChild(card);
    });

    grid.querySelectorAll('.download-btn').forEach(btn => {
      btn.addEventListener('click', () => downloadImage(parseInt(btn.dataset.index)));
    });
  } else {
    grid.innerHTML = '';
    empty.style.display = 'block';
    downloadAllBtn.disabled = true;
  }
}

async function downloadImage(index) {
  const item = processedImages[index];
  if (!item) return;

  try {
    const buffer = await item.file.arrayBuffer();
    const result = await invoke('save_image', {
      path: downloadPath || '.',
      filename: item.file.name,
      data: Array.from(new Uint8Array(buffer))
    });
    showToast(`Saved: ${result}`);
  } catch (e) {
    // Fallback: browser download
    const url = URL.createObjectURL(item.file);
    const a = document.createElement('a');
    a.href = url;
    a.download = item.file.name;
    a.click();
    URL.revokeObjectURL(url);
    showToast(`Downloaded: ${item.file.name}`);
  }
}

async function downloadAll() {
  if (processedImages.length === 0) return;
  for (let i = 0; i < processedImages.length; i++) {
    await new Promise(r => setTimeout(r, 150));
    await downloadImage(i);
  }
  showToast('All images downloaded');
}

// Settings
function openSettings() {
  document.getElementById('filename-prefix').value = settings.filenamePrefix;
  document.getElementById('custom-prefix-input').value = settings.customPrefix;
  document.getElementById('keep-original-filename').checked = settings.keepOriginalFilename;
  document.getElementById('custom-prefix-row').style.display = settings.filenamePrefix === 'custom' ? 'block' : 'none';
  document.getElementById('settings-modal').classList.add('show');
}

function closeSettings() {
  document.getElementById('settings-modal').classList.remove('show');
}

function saveSettings() {
  settings.filenamePrefix = document.getElementById('filename-prefix').value;
  settings.customPrefix = document.getElementById('custom-prefix-input').value;
  settings.keepOriginalFilename = document.getElementById('keep-original-filename').checked;
  localStorage.setItem('geostamp-settings', JSON.stringify(settings));
  closeSettings();
  showToast('Settings saved');
}

function loadSettings() {
  const saved = localStorage.getItem('geostamp-settings');
  if (saved) {
    try {
      settings = { ...settings, ...JSON.parse(saved) };
    } catch (e) {}
  }
}

// Event listeners
document.addEventListener('DOMContentLoaded', async () => {
  loadSettings();
  await initDownloadPath();

  document.getElementById('settings-btn').addEventListener('click', openSettings);
  document.getElementById('settings-cancel').addEventListener('click', closeSettings);
  document.getElementById('settings-save').addEventListener('click', saveSettings);
  document.getElementById('filename-prefix').addEventListener('change', (e) => {
    document.getElementById('custom-prefix-row').style.display = e.target.value === 'custom' ? 'block' : 'none';
  });

  document.getElementById('select-path-btn').addEventListener('click', selectDownloadPath);

  const uploadArea = document.getElementById('upload-area');
  const fileInput = document.getElementById('file-input');

  uploadArea.addEventListener('click', () => fileInput.click());
  uploadArea.addEventListener('dragover', (e) => { e.preventDefault(); });
  uploadArea.addEventListener('drop', handleDrop);
  fileInput.addEventListener('change', handleFileSelect);

  document.getElementById('process-btn').addEventListener('click', processImages);
  document.getElementById('download-all-btn').addEventListener('click', downloadAll);

  document.getElementById('settings-modal').addEventListener('click', (e) => {
    if (e.target === e.currentTarget) closeSettings();
  });
});
